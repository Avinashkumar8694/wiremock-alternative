const mongoose = require('mongoose');

const orgSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  createdDate: {
    type: Date,
    default: Date.now
  },
  domain: {
    type: String,
  }
});

module.exports = mongoose.model('Org', orgSchema);
